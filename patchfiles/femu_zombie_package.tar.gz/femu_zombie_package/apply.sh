#!/bin/bash
set -e

echo "=== Applying Zombie Research Patch ==="

# Clone FEMU
git clone https://github.com/MoatLab/FEMU.git
cd FEMU

# Apply YOUR patch file
echo "Applying femu_zombie_patch.patch..."
if [ -f "../femu_zombie_patch.patch" ]; then
    git apply ../femu_zombie_patch.patch
    echo "✓ Patch applied"
else
    echo "ERROR: femu_zombie_patch.patch not found!"
    echo "Place it in same directory as this script"
    exit 1
fi

# Build
echo "Building FEMU..."
mkdir -p build-femu
cd build-femu
../configure
make -j$(nproc)

echo "=== DONE ==="
echo "Run: ./qemu-system-x86_64 -device femu,devsz_mb=16384,femu_mode=1 ..."
